import React, { Component } from 'react';
import './header.css';

class Header extends Component {
    render() {
        return (
            <div className="header">
                <a className="header-name1">To-Do <span className="header-span">Application</span></a><br></br>
                
            </div>
        );
    }
}

export default Header;